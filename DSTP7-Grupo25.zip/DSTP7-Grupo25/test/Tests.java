/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import dstp7.model.DiaSemana;
import dstp7.model.Negocio;
import dstp7.model.Venta;

import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author miguel
 */
public class Tests {
    
    public Tests() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void regla1DosProductosIgualesRubroPanaderia() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 2);
        venta.AgregarDetalle(Negocio.Productos()[2], 2);
        venta.AgregarDetalle(Negocio.Productos()[6], 2);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Lunes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(39, descuento, 0);
    }
    @Test
    public void regla1ProductosDeOtroRubroDistintoDePanaderia() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[1], 3);
        venta.AgregarDetalle(Negocio.Productos()[2], 3);
        venta.AgregarDetalle(Negocio.Productos()[3], 3);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Lunes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(0 , descuento, 0);
    }
    @Test
    public void regla1DistintoDeDosOTresProductosIgualesRubroPanaderia() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 1);
        venta.AgregarDetalle(Negocio.Productos()[2], 3);
        venta.AgregarDetalle(Negocio.Productos()[6], 4);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Lunes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(28 , descuento, 0);
    }
    
    @Test
    public void regla2MartesComprasSuperiores500Menor1000() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 15);
        venta.AgregarDetalle(Negocio.Productos()[1], 2);
        venta.AgregarDetalle(Negocio.Productos()[5], 4);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Martes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(((15*50+2*30+4*15)*0.03) , descuento, 0);
    }
    @Test
    public void regla2MartesComprasSuperiores1000Hasta2500() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 22);
        venta.AgregarDetalle(Negocio.Productos()[1], 2);
        venta.AgregarDetalle(Negocio.Productos()[5], 4);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Martes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(((50*22+2*30+4*15)*0.05) , descuento, 0);
    }
    @Test
    public void regla2MartesComprasSuperiores2500() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 51);
        venta.AgregarDetalle(Negocio.Productos()[1], 2);
        venta.AgregarDetalle(Negocio.Productos()[5], 4);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Martes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(((51*50+2*30+4*15)*0.065) , descuento, 0);
    }
     
    @Test
    public void regla3JuevesDosProductosIgualesRubroLacteos() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[1], 2);
        venta.AgregarDetalle(Negocio.Productos()[6], 1);
        venta.AgregarDetalle(Negocio.Productos()[0], 8);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Jueves);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals((30*0.3) , descuento, 0);
    }
    @Test
    public void regla3JuevesCuatroProductosIgualesRubroLacteos() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[1], 4);
        venta.AgregarDetalle(Negocio.Productos()[6], 1);
        venta.AgregarDetalle(Negocio.Productos()[0], 8);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Jueves);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals((3*30*0.3) , descuento, 0);
    }
       @Test
    public void regla3JuevesSieteProductosIgualesRubroLacteos() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[1], 7);
        venta.AgregarDetalle(Negocio.Productos()[6], 1);
        venta.AgregarDetalle(Negocio.Productos()[0], 3);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Jueves);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals((4*30*0.3) , descuento, 0);
    }
    
    @Test
    public void regla3JuevesUnSoloProductoRubroLacteos() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[1], 1);
        venta.AgregarDetalle(Negocio.Productos()[6], 1);
        venta.AgregarDetalle(Negocio.Productos()[0], 8);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Jueves);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(0 , descuento, 0);
    }
    
    @Test
    public void regla4ViernesCompraMenor1000() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 4);
        venta.AgregarDetalle(Negocio.Productos()[1], 2);
        venta.AgregarDetalle(Negocio.Productos()[5], 3);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Viernes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(0 , descuento, 0);
    }
    @Test
    public void regla4ViernesCompraMayor1500() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 25);
        venta.AgregarDetalle(Negocio.Productos()[5], 4);
        venta.AgregarDetalle(Negocio.Productos()[1], 3);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Viernes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals((50*25*0.1+15*4*0.1) , descuento, 0);
    }
    @Test
    //Se agregó un nuevo producto a la lista: "_productos[7] = new Producto(8, "8", 1100, rubro1)"
    public void regla4UnProductoCompraMayor1000() {
        //Definicion
        Negocio.Iniciar();
        Venta venta = new Venta();
        venta.AgregarDetalle(Negocio.Productos()[0], 1);
        venta.AgregarDetalle(Negocio.Productos()[1], 1);
        venta.AgregarDetalle(Negocio.Productos()[7], 1);
        double descuento;
        //Ejecucion
        venta.CalcularDescuentos(DiaSemana.Viernes);
        descuento = venta.Descuento();
        //Comprobacion
        assertEquals(0 , descuento, 0);
    }
    
}
