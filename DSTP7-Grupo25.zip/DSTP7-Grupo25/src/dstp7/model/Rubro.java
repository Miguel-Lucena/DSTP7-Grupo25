package dstp7.model;
public class Rubro {
  public Rubro(){}

  public Rubro(int codigo, String descripcion){
     Codigo = codigo;
     Descripcion = descripcion;
  }
  public int Codigo;
  public String Descripcion;
}
