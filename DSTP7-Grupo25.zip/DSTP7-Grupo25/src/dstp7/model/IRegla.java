package dstp7.model;
public interface IRegla {
    double RealizarDescuento(Venta venta);
}
