package dstp7;
import dstp7.model.Negocio;
public class Main {
    public static void main(String[] args) {
        Negocio.Iniciar();
    }
}
